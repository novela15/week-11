pi = 3.14

def hitung_luas_lingkaran(jari_jari):
    return pi * (jari_jari ** 2)

def hitung_luas_persegi(sisi):
    return sisi ** 2 

